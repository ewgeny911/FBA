
﻿/*
 * Создано в SharpDevelop.
 * Пользователь: Travin
 * Дата: 01.11.2017
 * Время: 18:17
 */
 
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace FBA
{       
    ///вапвапвап
    public static partial class MethodDocument
    {
        //Конструктор
        static MethodDocument()
        {
            //sys.ConnectLocal();
            //sys.ConnectRemote(); 
        }
        
        //Метод удаления объекта документ.
        public static void Delete()
        {
        	sys.SM("Метод удаления документа");
        }
        
    }
}
